
public class MyStackException extends Exception {

}
