
public class StackUtility {
	static String alphabets = "abcdefghijklmnopqrstuvwxyz";

	public static String operate(MyStack s1, MyStack s2) throws Exception {
		MyStack s3 = new StackLinkedList();

		while (s1.size() > 1 && s2.size() > 0) {
			int a = s1.top();
			s1.pop();
			int b = s1.top();
			s1.pop();

			int op = s2.top();
			s2.pop();

			if (op < 0) {
				int c = a - b;
				s3.push(c);
			} else if (op >= 0) {
				int c = a + b;
				s3.push(c);
			}
		}

		int n = s3.size();
		String word = "";

		for (int i = 0; i < n; i++) {
			int a = s3.top();
			s3.pop();

			char w = alphabets.charAt(a);
			word = word + w;

		}

		return word;

	}
}
